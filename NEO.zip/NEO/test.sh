#!/usr/bin/sh

#echo "launching java app NeoBrowser.jar"
java -cp ./gson-2.8.5.jar:./NeoBrowser.jar NeoBrowser
